import { useState, useEffect } from 'react';
import axios from 'axios';
import './MeetList.css';

const MeetList = () => {
  const [meets, setMeets] = useState([]);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);

  const MEET_LINKS_ENDPOINT = 'http://127.0.0.1:8000/api/meet-links/';

  useEffect(() => {
    const fetchMeets = async () => {
      try {
        const response = await axios.get(MEET_LINKS_ENDPOINT, {
          headers: {
            // Add if authentication is required
            // Authorization: `Bearer ${localStorage.getItem('token')}`,
          },
        });
        console.log('✅ Meet links fetched:', response.data);
        setMeets(response.data);
      } catch (error) {
        const errorText =
          error.response?.status === 405
            ? `Method Not Allowed (405): Check if '${MEET_LINKS_ENDPOINT}' supports GET. Ensure the backend has a GET endpoint for meet links.`
            : error.response?.data?.detail ||
              error.response?.data?.error ||
              JSON.stringify(error.response?.data) ||
              'Failed to fetch meet links.';
        console.error('❌ Fetch meet links error:', error.response?.data, 'Status:', error.response?.status);
        setError(errorText);
      } finally {
        setLoading(false);
      }
    };
    fetchMeets();
  }, []);

  // Format ISO 8601 date to readable format (PKT: UTC+5)
  const formatDate = (isoDate) => {
    return new Date(isoDate).toLocaleString('en-US', {
      dateStyle: 'medium',
      timeStyle: 'short',
      timeZone: 'Asia/Karachi',
    });
  };

  return (
    <div className="meet-list">
      <h2>Scheduled Meets</h2>
      {loading && <p>Loading meet links...</p>}
      {error && (
        <div className="alert alert-danger" role="alert">
          {error}
        </div>
      )}
      {!loading && meets.length === 0 && !error && <p>No meet links available.</p>}
      <div className="meet-grid">
        {meets.map((meet) => (
          <div key={meet.id} className="meet-card">
            <h3>{meet.title}</h3>
            <p>
              <strong>Scheduled:</strong> {formatDate(meet.scheduled_at)}
            </p>
            <a
              href={meet.meet_link}
              target="_blank"
              rel="noopener noreferrer"
              className="btn btn-primary"
            >
              Join Meet
            </a>
          </div>
        ))}
      </div>
    </div>
  );
};

export default MeetList;