// import React from 'react';
// import { Check, ArrowLeft, TrendingUp } from 'lucide-react';
// import { useNavigate } from 'react-router-dom'; // Import useNavigate from React Router
// import { Card, CardContent, CardHeader, CardActions, Typography, Button, Box, LinearProgress } from '@mui/material'; // Import Material-UI components
// import NavbarComponent from './Navbar';
// import './FeedbackComponent.css'; // Import CSS file

// const FeedbackComponent = ({ score = 85, improvements = ['Comprehension'] }) => {
//   const navigate = useNavigate(); // Initialize the navigate hook

//   // Calculate color based on score
//   const getScoreColor = (score) => {
//     if (score >= 90) return 'green';
//     if (score >= 70) return 'blue';
//     return 'yellow';
//   };

//   // Get feedback message based on score
//   const getFeedbackMessage = (score) => {
//     if (score >= 90) return 'Excellent work! You\'re mastering the material.';
//     if (score >= 70) return 'Good job! You\'re showing solid understanding.';
//     return 'Keep practicing! You\'re making progress.';
//   };

//   return (
//     <>
//       <NavbarComponent />
//       <Card className="feedback-card">
//         <CardHeader
//           title="Your Feedback"
//           titleTypographyProps={{ variant: 'h6' }}
//           className="feedback-card-header"
//         />

//         <CardContent>
//           {/* Success Icon */}
//           <Box display="flex" justifyContent="center" mb={2}>
//             <Box className="feedback-icon-box">
//               <Check className="feedback-icon" />
//             </Box>
//           </Box>

//           {/* Score Section */}
//           <Box textAlign="center" mb={2}>
//             <Typography variant="body2" className="feedback-score-text">
//               Score
//             </Typography>
//             <Typography
//               variant="h4"
//               fontWeight="bold"
//               className="feedback-score"
//               style={{ color: getScoreColor(score) }}
//             >
//               {score}%
//             </Typography>
//           </Box>

//           {/* Progress Bar */}
//           <Box mb={2}>
//             <LinearProgress
//               variant="determinate"
//               value={score}
//               className="feedback-progress-bar"
//             />
//           </Box>

//           {/* Feedback Message */}
//           <Typography className="feedback-message">
//             {getFeedbackMessage(score)}
//           </Typography>

//           {/* Improvements Section */}
//           {improvements.length > 0 && (
//             <Box>
//               <Typography
//                 variant="body2"
//                 className="feedback-improvements-title"
//               >
//                 <TrendingUp style={{ fontSize: 16 }} />
//                 Areas for Improvement:
//               </Typography>
//               <Box component="ul" className="feedback-improvements-list">
//                 {improvements.map((item, index) => (
//                   <Typography
//                     key={index}
//                     variant="body2"
//                     component="li"
//                     className="feedback-improvements-item"
//                   >
//                     {item}
//                   </Typography>
//                 ))}
//               </Box>
//             </Box>
//           )}
//         </CardContent>

//         <CardActions>
//           <Button
//             className="feedback-back-button"
//             variant="contained"
//             color="success"
//             onClick={() => navigate('/Dashboard')}
//             startIcon={<ArrowLeft />}
//           >
//             Back to Dashboard
//           </Button>
//         </CardActions>
//       </Card>
//     </>
//   );
// };

// export default FeedbackComponent;


"use client"
import { Check, X, ArrowLeft, BookOpen } from "lucide-react"
import { useNavigate, useLocation } from "react-router-dom"
import {
  Card,
  CardContent,
  CardHeader,
  Typography,
  Button,
  Box,
  LinearProgress,
  Accordion,
  AccordionSummary,
  AccordionDetails,
  Chip,
} from "@mui/material"
import ExpandMoreIcon from "@mui/icons-material/ExpandMore"

const FeedbackComponent = () => {
  const navigate = useNavigate()
  const location = useLocation()

  // Get evaluation data from navigation state
  const evaluation = location.state?.evaluation

  // If no evaluation data, redirect back
  if (!evaluation) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" minHeight="50vh">
        <Card>
          <CardContent>
            <Typography>No evaluation data found. Please take the test first.</Typography>
            <Button onClick={() => navigate("/Dashboard")} sx={{ mt: 2 }}>
              Back to Dashboard
            </Button>
          </CardContent>
        </Card>
      </Box>
    )
  }

  const { percentage, user_score, total_score_of_test, feedback, test_type } = evaluation

  // Calculate color based on score
  const getScoreColor = (score) => {
    if (score >= 90) return "#4caf50" // green
    if (score >= 70) return "#2196f3" // blue
    if (score >= 50) return "#ff9800" // orange
    return "#f44336" // red
  }

  // Get feedback message based on score
  const getFeedbackMessage = (score) => {
    if (score >= 90) return "Excellent work! You're mastering the material."
    if (score >= 70) return "Good job! You're showing solid understanding."
    if (score >= 50) return "Fair performance. Keep practicing to improve."
    return "Keep practicing! You're making progress."
  }

  // Get question status icon
  const getQuestionIcon = (score) => {
    return score > 0 ? (
      <Check style={{ color: "#4caf50", fontSize: 20 }} />
    ) : (
      <X style={{ color: "#f44336", fontSize: 20 }} />
    )
  }

  // Calculate statistics
  const correctAnswers = feedback.filter((item) => item.score > 0).length
  const incorrectAnswers = feedback.filter((item) => item.score === 0).length

  return (
    <Box sx={{ padding: 2, maxWidth: 1200, margin: "0 auto" }}>
      {/* Overall Results Card */}
      <Card sx={{ mb: 3 }}>
        <CardHeader
          title="Test Results"
          titleTypographyProps={{ variant: "h5", fontWeight: "bold" }}
          sx={{ textAlign: "center", pb: 1 }}
        />

        <CardContent>
          {/* Success/Score Icon */}
          <Box display="flex" justifyContent="center" mb={2}>
            <Box
              sx={{
                width: 80,
                height: 80,
                borderRadius: "50%",
                backgroundColor: getScoreColor(percentage),
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                color: "white",
              }}
            >
              {percentage >= 50 ? <Check size={40} /> : <X size={40} />}
            </Box>
          </Box>

          {/* Score Section */}
          <Box textAlign="center" mb={3}>
            <Typography variant="h3" fontWeight="bold" sx={{ color: getScoreColor(percentage) }}>
              {percentage}%
            </Typography>
            <Typography variant="h6" color="textSecondary">
              {user_score} out of {total_score_of_test} correct
            </Typography>
          </Box>

          {/* Progress Bar */}
          <Box mb={3}>
            <LinearProgress
              variant="determinate"
              value={percentage}
              sx={{
                height: 10,
                borderRadius: 5,
                backgroundColor: "#e0e0e0",
                "& .MuiLinearProgress-bar": {
                  backgroundColor: getScoreColor(percentage),
                },
              }}
            />
          </Box>

          {/* Statistics */}
          <Box display="flex" justifyContent="space-around" mb={3}>
            <Box textAlign="center">
              <Typography variant="h6" color="success.main" fontWeight="bold">
                {correctAnswers}
              </Typography>
              <Typography variant="body2" color="textSecondary">
                Correct
              </Typography>
            </Box>
            <Box textAlign="center">
              <Typography variant="h6" color="error.main" fontWeight="bold">
                {incorrectAnswers}
              </Typography>
              <Typography variant="body2" color="textSecondary">
                Incorrect
              </Typography>
            </Box>
            <Box textAlign="center">
              <Typography variant="h6" color="primary.main" fontWeight="bold">
                {test_type.toUpperCase()}
              </Typography>
              <Typography variant="body2" color="textSecondary">
                Test Type
              </Typography>
            </Box>
          </Box>

          {/* Feedback Message */}
          <Typography
            variant="body1"
            textAlign="center"
            sx={{
              fontStyle: "italic",
              color: "textSecondary",
              backgroundColor: "#f5f5f5",
              padding: 2,
              borderRadius: 1,
            }}
          >
            {getFeedbackMessage(percentage)}
          </Typography>
        </CardContent>
      </Card>

      {/* Detailed Question Feedback */}
      <Card>
        <CardHeader
          title={
            <Box display="flex" alignItems="center" gap={1}>
              <BookOpen size={24} />
              <Typography variant="h6">Detailed Question Analysis</Typography>
            </Box>
          }
        />
        <CardContent>
          {feedback.map((item, index) => (
            <Accordion key={index} sx={{ mb: 1 }}>
              <AccordionSummary
                expandIcon={<ExpandMoreIcon />}
                sx={{
                  backgroundColor: item.score > 0 ? "#e8f5e8" : "#ffeaea",
                  "&:hover": {
                    backgroundColor: item.score > 0 ? "#d4edda" : "#f8d7da",
                  },
                }}
              >
                <Box display="flex" alignItems="center" gap={2} width="100%">
                  {getQuestionIcon(item.score)}
                  <Typography variant="body1" fontWeight="medium" sx={{ flexGrow: 1 }}>
                    Question {index + 1}: {item.question}
                  </Typography>
                  <Chip
                    label={item.score > 0 ? "Correct" : "Incorrect"}
                    color={item.score > 0 ? "success" : "error"}
                    size="small"
                  />
                </Box>
              </AccordionSummary>
              <AccordionDetails>
                <Box>
                  <Typography variant="body2" color="textSecondary" gutterBottom>
                    <strong>Your Answer:</strong> {item.user_answer}
                  </Typography>
                  {item.correct_answer && (
                    <Typography variant="body2" color="success.main" gutterBottom>
                      <strong>Correct Answer:</strong> {item.correct_answer}
                    </Typography>
                  )}
                  <Typography variant="body2" sx={{ mt: 1 }}>
                    <strong>Feedback:</strong> {item.ai_feedback}
                  </Typography>
                  <Box mt={1}>
                    <Chip
                      label={`Score: ${item.score}/${item.type === "subjective" ? "20" : "1"}`}
                      variant="outlined"
                      size="small"
                    />
                  </Box>
                </Box>
              </AccordionDetails>
            </Accordion>
          ))}
        </CardContent>
      </Card>

      {/* Action Buttons */}
      <Box display="flex" justifyContent="center" gap={2} mt={3}>
        <Button
          variant="contained"
          color="primary"
          onClick={() => navigate("/Dashboard")}
          startIcon={<ArrowLeft />}
          size="large"
        >
          Back to Dashboard
        </Button>
        <Button variant="outlined" color="secondary" onClick={() => navigate("/test-interface")} size="large">
          Retake Test
        </Button>
      </Box>
    </Box>
  )
}

export default FeedbackComponent
